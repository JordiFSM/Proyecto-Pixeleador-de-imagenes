﻿

Public Class frmMain
    Public Property Formato As String = "No"

    Public Property CheckPaleta As Boolean = False
    Public Property Poblacion As New List(Of ClassIndividuo)

    Public Property Poblaciones As New List(Of List(Of ClassIndividuo))

    Public Property PoblacionesNuevas As New List(Of Integer)
    Public Property Generacion As Integer = 0
    Public Property GeneracionAct As Integer = 0
    Public Property Mejores As Integer = 0
    Public Property MejoresTotales As Integer = 0
    Public Property BestIndividuo As ClassIndividuo
    Public Property WorseIndividuo As ClassIndividuo
    Public Property SecondIndividuo As ClassIndividuo
    Public Property PaletaColores As New List(Of Color)

    Public Property MatrizPixelColorObjetivoReducida As New List(Of List(Of Color))
    Public Property MatrizPixelColorObjetivo As List(Of List(Of Color))
    Public Property h1 As System.Threading.Thread
    Public Property HiloPause As Boolean = False
    Public Property vFlag As Boolean = True

    '####################################################
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CheckForIllegalCrossThreadCalls = False
    End Sub

    '=================================== ============================ 
    'inicializaMatrizPixelColor 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crear una lista de listas de colores
    ' 
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: una lista de listas de colores o una matriz de colores
    'asemejando la matriz de pixeles de los individuos que serán creados a partir de la imagen
    '================================ ===============================
    Public Function inicializaMatrizPixelColor() As List(Of List(Of Color))
        Randomize()
        Dim res As New List(Of List(Of Color))
        For i = 0 To MatrizPixelColorObjetivoReducida.Count - 1
            Dim rowTemp As New List(Of Color)
            For j = 0 To MatrizPixelColorObjetivoReducida(0).Count - 1
                rowTemp.Add(Color.FromArgb(Rnd() * 255, Rnd() * 255, Rnd() * 255))
            Next
            res.Add(rowTemp)
        Next
        Return res
    End Function

    '=================================== ============================ 
    'inicializaMatrizPixelCondicion 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crear una lista de listas de boleanos esto para saber cuales pixeles de
    ' los individuos a crear son posibles cambiar y cuales no.
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: una lista de listas de booleanos o una matriz de booleanos
    'asemejando la matriz de pixeles de los individuos que serán creados a partir de la imagen
    '================================ ===============================
    Public Function inicializaMatrizPixelCondicion() As List(Of List(Of Boolean))
        Dim res As New List(Of List(Of Boolean))
        For i = 0 To MatrizPixelColorObjetivoReducida.Count - 1
            Dim rowTemp As New List(Of Boolean)
            For j = 0 To MatrizPixelColorObjetivoReducida(0).Count - 1
                rowTemp.Add(True)
            Next
            res.Add(rowTemp)
        Next
        Return res
    End Function

    '=================================== ============================ 
    'begingPoblation 
    ' ------------------- -------------------------------------------- 
    'Propósito: Inicializar la poblacion con la que se iniciara el algorítmo genético.
    ' 
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'Index será el tamaño de la poblacion a inicializar
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/A
    '================================ ===============================
    Public Sub begingPoblation(pIndex As Integer)
        Generacion += 1
        Dim BestIndividuo2 As New ClassIndividuo(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count, inicializaMatrizPixelColor(), inicializaMatrizPixelCondicion(), Generacion)
        Dim SecondIndividuo2 As New ClassIndividuo(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count, inicializaMatrizPixelColor(), inicializaMatrizPixelCondicion(), Generacion)
        Dim WorseIndividuo2 As New ClassIndividuo(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count, inicializaMatrizPixelColor(), inicializaMatrizPixelCondicion(), Generacion)
        BestIndividuo2.Fitness = 0
        SecondIndividuo2.Fitness = 0
        WorseIndividuo2.Fitness = 0
        BestIndividuo = BestIndividuo2
        SecondIndividuo = SecondIndividuo2
        WorseIndividuo = WorseIndividuo2
        For i = 0 To pIndex - 1
            Dim inT As New ClassIndividuo(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count, inicializaMatrizPixelColor(), inicializaMatrizPixelCondicion(), Generacion)
            Poblacion.Add(inT)
            fitnessIndividual(inT)
            isBestSecond(inT, 1)
            If inT.Fitness < WorseIndividuo.Fitness Then
                WorseIndividuo = inT
            End If
        Next
        GeneracionAct += 1
        PoblacionesNuevas.Add(0)
    End Sub

    '=================================== ============================ 
    'createImagePixel 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crea un bitmap, a partir de la matriz de pixeles ingresado, cambia pixel por pixel
    ' el bitmap en las mismas posicione que se encuentre tanto en la matriz como en el bitmap
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pListaColors será la matriz de la cual se obtendran los pixeles que se intercambiarán en el bitmap
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: Un bitmap
    '=================================== ============================
    Public Function createImagePixel(pListaColors As List(Of List(Of Color))) As Bitmap
        Dim bitmapTemp As New Bitmap(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count)
        For i = 0 To bitmapTemp.Height - 1
            For j = 0 To bitmapTemp.Width - 1
                bitmapTemp.SetPixel(j, i, pListaColors(i)(j))
            Next j
        Next i
        Return bitmapTemp
    End Function

    '=================================== ============================ 
    'matrizImagenPixels 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crea un a matriz de colores de la imagen original a pixelear
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros N/A
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: Una matriz de colores
    '=================================== ============================
    Public Function matrizImagenPixels() As List(Of List(Of Color))
        Dim vMatrizP As New List(Of List(Of Color))
        Dim vImagen As Bitmap = PictureBox1.Image
        For i = 0 To PictureBox1.Image.Height - 1
            Dim vFila As New List(Of Color)
            For j = 0 To PictureBox1.Image.Width - 1
                vFila.Add(vImagen.GetPixel(j, i))
            Next j
            vMatrizP.Add(vFila)
        Next i
        Return vMatrizP
    End Function

    '=================================== ============================ 
    'loadImage 
    ' ------------------- -------------------------------------------- 
    'Propósito: Carga la imagen que se busco en los archivos en el picturebox1 ademas utiliza el método que
    ' creará la matriz de la version pixeleada de esta.
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'path es la direccion del archivo
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/A
    '=================================== ============================
    Private Sub loadImage(path As String)
        Dim b As New Bitmap(path)
        PictureBox1.Image = b
        Label15.Text = CStr(b.Height)
        Label16.Text = CStr(b.Width)
        MatrizPixelColorObjetivo = matrizImagenPixels()
        MatrizPixelColorObjetivo = pixelearBitMap(MatrizPixelColorObjetivo, MatrizPixelColorObjetivo.Count - 1, MatrizPixelColorObjetivo(0).Count - 1, 20, 20)
        MatrizPixelColorObjetivo = MatrizPixelColorObjetivoReducida
        CheckBox1.Enabled = True
        Button1.Enabled = False
    End Sub

    '=================================== ============================ 
    'Button1_Click 
    ' ------------------- -------------------------------------------- 
    'Propósito: Buscar la imagen con el formato seleccionado y cargar la misma
    ' 
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'N/A
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/A
    '=================================== ============================
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Using oD As New OpenFileDialog()
            With oD
                .Filter = Formato + " File(*." + Formato + ")|*." + Formato
                .Title = "Choose Image"
                If .ShowDialog = Windows.Forms.DialogResult.OK Then
                    loadImage(.FileName)
                End If
                .Dispose()
            End With
        End Using
    End Sub

    '=================================== ============================ 
    'fitnessIndividual 
    ' ------------------- -------------------------------------------- 
    'Propósito: Buscar la el parecido de la matriz de colores del individuo con la
    ' matriz de colores objetivo, esta matriz es la de la versión pixeleada de la imagen original y cambiarlo 
    ' Autor: Amira Acevedo, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pIndividuo es el individuo del que se sacara la matriz de colores
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/A
    '=================================== ============================
    Public Sub fitnessIndividual(pIndividuo As ClassIndividuo)
        Dim vMax As Integer = pIndividuo.Largo * pIndividuo.Ancho
        Dim vEqual As New Integer
        For i = 0 To pIndividuo.Largo - 1
            For j = 0 To pIndividuo.Ancho - 1
                If pIndividuo.MatrizPixelColor(i)(j) = MatrizPixelColorObjetivo(i)(j) Then
                    vEqual += 1
                    pIndividuo.MatrizPixelCondicion(i)(j) = False
                End If
            Next
        Next
        pIndividuo.Fitness = (vEqual * 100) / vMax
    End Sub

    '=================================== ============================ 
    'isBestSecond 
    ' ------------------- -------------------------------------------- 
    'Propósito: Cambiar el mejor individuo y el segundo si el individuo parametro tiene un mejor
    ' porcentaje de fitnes que el mejor y el segundo mejor
    ' Autor: Amira Acevedo, Junio de 2021
    ' 
    ' Notas: 
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pIndividuo es el individuo que se comparará con el mejor y el segundo mejor, pCuenta es un caso 
    'especial para cuando se inicialice la poblacion solo se tome en cuenta 1 inddividuo en los mejores
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/A
    '=================================== ============================
    Public Sub isBestSecond(pIndividuo As ClassIndividuo, pCuenta As Integer)
        If pCuenta = 1 Then
            Mejores = 1
            MejoresTotales = 1
        End If
        If pIndividuo.Fitness >= BestIndividuo.Fitness Then
            If pIndividuo.Fitness > BestIndividuo.Fitness And pCuenta <> 1 And BestIndividuo.gen <> pIndividuo.gen Then
                Mejores += 1
                MejoresTotales += 1
            End If
            SecondIndividuo = BestIndividuo
            BestIndividuo = pIndividuo
        ElseIf pIndividuo.Fitness >= SecondIndividuo.Fitness Then
            SecondIndividuo = pIndividuo
        End If
    End Sub

    '=================================== ============================ 
    'cruceMejoresIndividuos 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crear un individuo a partir de la reproduccion del mejor individuo y el segundo mejor, 
    ' 
    ' Autor: Amira Acevedo, Junio de 2021
    ' 
    ' Notas: Se crea el 9,2% de probabilidad de mutación a la hora de la creación
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'N/A
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: Un Individuo creado a partir del mejor y segundo mejor individuo
    '=================================== ============================
    Public Function cruceMejoresIndividuos() As ClassIndividuo
        Randomize()
        Dim inT As New ClassIndividuo(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count, inicializaMatrizPixelColor(), inicializaMatrizPixelCondicion(), Generacion)
        Dim vMutee As Boolean = False
        If (Rnd() * 100) <= NumericUpDown1.Value Then
            vMutee = True
        End If
        For j = 0 To inT.MatrizPixelColor.Count - 1
            For k = 0 To inT.MatrizPixelColor(j).Count - 1
                inT.MatrizPixelColor(j)(k) = defineColor(j, k, vMutee)
            Next
        Next
        fitnessIndividual(inT)
        Return inT
    End Function

    '=================================== ============================ 
    'defineColor 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crea un color a parti de la matriz de condiciones del mejor y segundo mejor individuo, tambien toma en cuenta el factor mutación
    ' 
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas: Se crea el 9,2% de probabilidad de mutación a la hora de la creación, al igual existe el 50/50 de tomar el gen paterno o materno
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pCromosoma fila de la matriz, pGen columna de la matriz, vMutee el factor de mutación.
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: Un color
    '=================================== ============================
    Public Function defineColor(pCromosoma As Integer, pGen As Integer, vMutee As Boolean) As Color
        If Not BestIndividuo.MatrizPixelCondicion(pCromosoma)(pGen) Then
            Return BestIndividuo.MatrizPixelColor(pCromosoma)(pGen)
        ElseIf Not SecondIndividuo.MatrizPixelCondicion(pCromosoma)(pGen) Then
            Return SecondIndividuo.MatrizPixelColor(pCromosoma)(pGen)
        Else
            If vMutee Then 'Existe un % de probabilidad de que los genes del cruce entre padres sea otro, osea mute el gen cruce
                If CheckBox1.Checked Then
                    Dim vRandom As Integer = Rnd() * (PaletaColores.Count - 1)
                    Return PaletaColores(vRandom)
                Else
                    Return Color.FromArgb(Rnd() * 255, Rnd() * 255, Rnd() * 255)
                End If
            Else
                Return Color.FromArgb(Rnd() * 255, Rnd() * 255, Rnd() * 255)
            End If
        End If
    End Function

    '=================================== ============================ 
    'deleteWorseIndividuos 
    ' ------------------- -------------------------------------------- 
    'Propósito: Elimina al peor individuos de la población
    ' 
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'N/A
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/a
    '=================================== ============================
    Public Sub deleteWorseIndividuos()
        Poblacion.Remove(WorseIndividuo)
        WorseIndividuo = SecondIndividuo
        For Each itm In Poblacion
            If itm.Fitness <= WorseIndividuo.Fitness Then
                WorseIndividuo = itm
            End If
        Next
    End Sub

    '=================================== ============================ 
    'createNewAge 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crea una nueva generación de individuos que se añadiran a la poblacion
    ' 
    ' Autor: Amira Acevedo, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pIndex es el numero de individuos a eliminar y crear
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/a
    '=================================== ============================
    Public Sub createNewAge(pIndex As Integer)
        Generacion += 1
        For i = 0 To pIndex
            deleteWorseIndividuos()
        Next
        Dim poblacionTemp As New List(Of ClassIndividuo)
        For i = 0 To pIndex
            Dim inT = cruceMejoresIndividuos()
            fitnessIndividual(inT)
            If inT.Fitness < WorseIndividuo.Fitness Then
                WorseIndividuo = inT
            End If
            poblacionTemp.Add(inT)
        Next
        For Each itm In poblacionTemp
            isBestSecond(itm, 0)
            Poblacion.Add(itm)
        Next
        Dim vPoblacionTemp2 As New List(Of ClassIndividuo)
        vPoblacionTemp2.Add(BestIndividuo)
        vPoblacionTemp2.Add(SecondIndividuo)
        Poblaciones.Add(vPoblacionTemp2)
        PoblacionesNuevas.Add(NumericUpDown2.Value)
        GeneracionAct += 1

    End Sub

    '=================================== ============================ 
    'geneticAlgorithm 
    ' ------------------- -------------------------------------------- 
    'Propósito: Crea un bucle que cree generaciones nuevas, lleve los datos al usuario, controle el factor pausa
    ' hasta que se reinicie o se llegue al objetivo que es 99% de firtness en un individuo
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'N/A
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: N/a
    '=================================== ============================
    Public Sub geneticAlgorithm()
        vFlag = True
        begingPoblation(30)
        Dim vPoblacionTemp As New List(Of ClassIndividuo)
        vPoblacionTemp.Add(BestIndividuo)
        vPoblacionTemp.Add(SecondIndividuo)
        Poblaciones.Add(vPoblacionTemp)
        While vFlag
            createNewAge(NumericUpDown2.Value)
            Label2.Text = CStr(GeneracionAct)
            Label4.Text = CStr(BestIndividuo.Fitness) + " %"
            Label6.Text = CStr(Mejores)
            Label14.Text = CStr(30 + PoblacionesNuevas(GeneracionAct - 1))
            PictureBox2.Image = createImagePixel(BestIndividuo.MatrizPixelColor)
            If BestIndividuo.Fitness > 99 Then
                vFlag = False
            End If
            If HiloPause Then
                While HiloPause
                    System.Threading.Thread.Sleep(500)
                End While
                System.Threading.Thread.Sleep(1000)
            End If
        End While
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        Formato = "PNG"
        RadioButton2.Enabled = False
        RadioButton3.Enabled = False
        Button2.Enabled = True
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        Formato = "JPEG"
        RadioButton2.Enabled = False
        RadioButton1.Enabled = False
        Button2.Enabled = True
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        Formato = "JPG"
        RadioButton1.Enabled = False
        RadioButton3.Enabled = False
        Button2.Enabled = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RadioButton1.Enabled = True
        RadioButton3.Enabled = True
        RadioButton2.Enabled = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Generacion = 0
        GeneracionAct = 0
        Mejores = 0
        MejoresTotales = 0
        Poblaciones.Clear()
        PoblacionesNuevas.Clear()
        MatrizPixelColorObjetivoReducida.Clear()
        vFlag = False
        HiloPause = False
        Label2.Text = "0"
        Label4.Text = "0 %"
        Label6.Text = "0"
        Label14.Text = "0"
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = False
        Button4.Enabled = False
        Button5.Enabled = True
        Button4.Text = "Pausar"
        PictureBox2.Image = Nothing
        PictureBox1.Image = Nothing
        Button6.Enabled = False
        Button7.Enabled = False
        Button8.Enabled = False
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If Formato <> "No" Then
            If Not PictureBox1.Image Is Nothing Then
                inicializarPaleta(MatrizPixelColorObjetivo)
                Button1.Enabled = False
                Button2.Enabled = False
                Button3.Enabled = False
                Button4.Enabled = True
                Button5.Enabled = False
                CheckBox1.Enabled = False
                HiloPause = False
                Label18.Text = CStr(MatrizPixelColorObjetivoReducida.Count)
                Label22.Text = CStr(MatrizPixelColorObjetivoReducida(0).Count)
                h1 = New System.Threading.Thread(AddressOf Me.geneticAlgorithm)
                h1.Start()
            Else
                MsgBox("Ingrese una imagen del formato seleccionado.", +vbExclamation, "Pixeleador")
            End If
        Else
            MsgBox("Seleccione un Formato de imagen!", vbExclamation, "Pixeleador")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If HiloPause Then
            Button3.Enabled = False
            HiloPause = False
            Button4.Text = "Pausar"
            Button7.Enabled = False
            Button6.Enabled = False
            Button8.Enabled = False
            CheckBox1.Enabled = False
        Else
            Button3.Enabled = True
            HiloPause = True
            Button4.Text = "Continuar"
            Button7.Enabled = True
            Button6.Enabled = True
            Button8.Enabled = True
            CheckBox1.Enabled = True
        End If
    End Sub

    '=================================== ============================ 
    'pixelearBitMap 
    ' ------------------- -------------------------------------------- 
    'Propósito: Es el algoritmo que crea la matriz de la imagen original, en version pixeleada, esto tomando las filas y columnas tomado 
    'un perimetro y sacando un promedio de este perimetro, se cambiara al color que más se repita en este perimetro completamente
    '
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pImage es la matriz de colores a cambiar, pFilas las filas de la matriz, pColumnas las columnas de la matriz, pAncho el ancho del pixeleado, pLargo el largo del pixeleado
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: Una matriz de colores de la imagen original pero en este caso sera de manera pixeleada
    '=================================== ============================
    Private Function pixelearBitMap(pImage As List(Of List(Of Color)), pFilas As Integer, pColumnas As Integer, pAncho As Integer, pLargo As Integer) As List(Of List(Of Color))
        Dim y As Integer = (pFilas / 75)  '<--------------------------------
        Dim x As Integer = (pColumnas / 72)  '<--------------------------------
        'If pFilas >= 700 Then
        ' y = (pFilas / 1700) * 8
        'End If
        ' If pColumnas >= 700 Then
        'x = (pColumnas / 1700) * 8
        ' End If
        Dim vPixeleo As Integer = (pColumnas / x) - 1
        Dim vFilaActual As Integer = 0
        While vFilaActual < pFilas - (y + 10)
            Dim vFilaActualTemp As Integer = vFilaActual
            Dim vColumnaActual As Integer = 0
            Dim vListaCF As New List(Of Color)
            For i = 0 To vPixeleo - 1
                Dim vLC As New List(Of Color)
                Dim vPosLC As New List(Of List(Of Integer))
                For j = 0 To y - 1
                    Dim vColumnaTemporal2 As Integer = vColumnaActual
                    For k = 0 To x - 1
                        Dim vListPos As New List(Of Integer)
                        vLC.Add(pImage(vFilaActualTemp)(vColumnaTemporal2))
                        vListPos.Add(vFilaActualTemp)
                        vListPos.Add(vColumnaTemporal2)
                        vPosLC.Add(vListPos)
                        vColumnaTemporal2 += 1
                    Next
                    vFilaActualTemp += 1
                Next
                Dim vColorCambio As Color = maximoColor(vLC)
                vListaCF.Add(vColorCambio)
                vListaCF.Add(vColorCambio)
                pImage = pixelearLista(pImage, vColorCambio, vPosLC)
                vFilaActualTemp = vFilaActual
                vColumnaActual += x
            Next
            MatrizPixelColorObjetivoReducida.Add(vListaCF)
            MatrizPixelColorObjetivoReducida.Add(vListaCF)
            vFilaActual += y
        End While
        Return pImage
    End Function

    '=================================== ============================ 
    'pixelearLista 
    ' ------------------- -------------------------------------------- 
    'Propósito: Cambiar el color de las listas de colores en las posiciones ingersadas por la lista de posiciones
    '
    '
    ' Autor: Amira Acevedo, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pImage es la matriz de colores a cambiar, pColor es el color a cambiar en todas las posiciones, pLista de aqui se tomaran las posiciones que se cambiaran
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: una matriz con los pixeles cambiados en las posiciones ingresadas
    '=================================== ============================
    Private Function pixelearLista(pImage As List(Of List(Of Color)), pColor As Color, pLista As List(Of List(Of Integer))) As List(Of List(Of Color))
        For Each item In pLista
            pImage(item(0))(item(1)) = pColor
        Next
        Return pImage
    End Function
    '=================================== ============================ 
    'maximoColor 
    ' ------------------- -------------------------------------------- 
    'Propósito: retorna el color que más se repita en la lista.
    '
    ' Autor: Amira Acevedo, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pImage es la lista de colores 
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: un color
    '=================================== ============================

    Private Function maximoColor(pListColor As List(Of Color)) As Color
        Dim vColor As New Color
        Dim vCantidad As Integer = 0
        For Each item In pListColor
            Dim vCont As Integer = 0
            For Each item2 In pListColor
                If item = item2 Then
                    vCont += 1
                End If
            Next
            If vCont > vCantidad Then
                vCantidad = vCont
                vColor = item
            End If
        Next
        Return vColor
    End Function

    '=================================== ============================ 
    'estaPoblacion 
    ' ------------------- -------------------------------------------- 
    'Propósito: verificar si el fitness individuo se encuentra en la población.
    '
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pIndividuo es del cual se tomara el Fitness para verificar en los individuos de la poblacion
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: un booleano
    '=================================== ============================
    Private Function estaPoblacion(pIndividuo As ClassIndividuo) As Boolean
        For Each itm In Poblacion
            If itm.Fitness = pIndividuo.Fitness Then
                Return True
            End If
        Next
        Return False
    End Function

    '=================================== ============================ 
    'buscarBestSecond 
    ' ------------------- -------------------------------------------- 
    'Propósito: Busca el mejor individuo de la lista de individuos ingresada
    '
    ' Autor: Jordi Segura, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pPoblacion es la lista de los individuos en la que se buscara el numero 1 o numero 2, pOper el individuo numero 1 o numero 2
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: un individuo
    '=================================== ============================
    Private Function buscarBestSecond(pPoblacion As List(Of ClassIndividuo), pOper As Integer) As ClassIndividuo
        Dim vBest As New ClassIndividuo(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count, inicializaMatrizPixelColor, inicializaMatrizPixelCondicion, GeneracionAct)
        Dim vSecond As New ClassIndividuo(MatrizPixelColorObjetivoReducida(0).Count, MatrizPixelColorObjetivoReducida.Count, inicializaMatrizPixelColor, inicializaMatrizPixelCondicion, GeneracionAct)
        vBest.Fitness = 0
        vSecond.Fitness = 0
        For Each item In pPoblacion
            If item.Fitness >= vBest.Fitness Then
                vSecond = vBest
                vSecond.MatrizPixelColor = vBest.MatrizPixelColor
                vBest = item
                vBest.MatrizPixelColor = item.MatrizPixelColor
            ElseIf item.Fitness >= vSecond.Fitness Then
                vSecond = item
                vSecond.MatrizPixelColor = item.MatrizPixelColor
            End If
        Next
        If pOper = 1 Then
            Return vBest
        Else
            Return vSecond
        End If
    End Function

    '=================================== ============================ 
    'organizarBestSecond 
    ' ------------------- -------------------------------------------- 
    'Propósito: Organiza la información visual con la generacion actual a la que se movio el usuario, ya sea que retrocedio o avanzo.
    '
    ' Autor: Amira Acevedo, Junio de 2021
    ' 
    ' Notas:
    ' ---------------------------------------- ----------------------- 
    'Parámetros 
    'pOper indica si se avanzo o se retrocedio en las generaciones
    ' ----------- 
    '--------------------------------------- ------------------------ 
    'Devuelve: un individuo
    '=================================== ============================
    Private Sub organizarBestSecond(pOper As Integer)
        If pOper = 0 Then
            If CStr(buscarBestSecond(Poblaciones(GeneracionAct - 1), 1).Fitness) + " %" <> Label4.Text Then
                Mejores -= 1
            End If
            PictureBox2.Image = createImagePixel(buscarBestSecond(Poblaciones(GeneracionAct - 1), 1).MatrizPixelColor)
            Label4.Text = CStr(buscarBestSecond(Poblaciones(GeneracionAct - 1), 1).Fitness) + " %"
        ElseIf pOper = 1 Then
            If CStr(buscarBestSecond(Poblaciones(GeneracionAct - 1), 1).Fitness) + " %" <> Label4.Text Then
                Mejores += 1
            End If
            PictureBox2.Image = createImagePixel(buscarBestSecond(Poblaciones(GeneracionAct - 1), 1).MatrizPixelColor)
            Label4.Text = CStr(buscarBestSecond(Poblaciones(GeneracionAct - 1), 1).Fitness) + " %"
        End If
        Label2.Text = CStr(GeneracionAct)
        Label6.Text = CStr(Mejores)
        Label14.Text = CStr(30 + PoblacionesNuevas(GeneracionAct - 1))
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If GeneracionAct > 1 Then
            GeneracionAct -= 1
            organizarBestSecond(0)
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If GeneracionAct = Generacion Then
            createNewAge(4)
            Label2.Text = CStr(GeneracionAct)
            Label4.Text = CStr(BestIndividuo.Fitness) + " %"
            Label6.Text = CStr(Mejores)
            Label14.Text = CStr(30 + PoblacionesNuevas(GeneracionAct - 1))
            PictureBox2.Image = createImagePixel(BestIndividuo.MatrizPixelColor)
        Else
            GeneracionAct += 1
            organizarBestSecond(1)
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        GeneracionAct = Generacion
        Mejores = MejoresTotales
        Label2.Text = CStr(GeneracionAct)
        Label4.Text = CStr(BestIndividuo.Fitness) + " %"
        Label6.Text = CStr(Mejores)
        PictureBox2.Image = createImagePixel(BestIndividuo.MatrizPixelColor)
    End Sub

    Public Sub inicializarPaleta(pImage As List(Of List(Of Color)))
        For Each vList In pImage
            For Each vColor In vList
                If Not estaColor(vColor) Then
                    PaletaColores.Add(vColor)
                End If
            Next
        Next
    End Sub

    Public Function estaColor(pColor As Color) As Boolean
        For Each vColor In PaletaColores
            If pColor = vColor Then
                Return True
            End If
        Next
        Return False
    End Function

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If Not PictureBox1.Image Is Nothing Then
            PictureBox2.Image = createImagePixel(MatrizPixelColorObjetivoReducida)
        End If
    End Sub
End Class
