﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class ClassIndividuo
    Public Property Ancho As Integer
    Public Property Largo As Integer
    Public Property Fitness As Single = 0
    Public Property MatrizPixelColor As List(Of List(Of Color))
    Public Property MatrizPixelCondicion As List(Of List(Of Boolean))

    Public gen As Integer

    Sub New(pAncho As Integer, pLargo As Integer, pMatrizPixelColor As List(Of List(Of Color)), pMatrizPixelCondicion As List(Of List(Of Boolean)), pGen As Integer)
        Me.Ancho = pAncho
        Me.Largo = pLargo
        MatrizPixelColor = pMatrizPixelColor
        MatrizPixelCondicion = pMatrizPixelCondicion
        gen = pGen
    End Sub

    Public Sub setMatrizCondicion(pMatriz As List(Of List(Of Color)))
        Me.MatrizPixelColor = pMatriz
    End Sub

End Class
